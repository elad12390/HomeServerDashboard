import {configuration, fetchStyle} from '../../../index.js'
let initialized = false
export const Gojo = async () => {
    if (!initialized) {
        initialized = true
        await fetchStyle('/src/components/Gojo/Gojo.css')
    }
    return `<img id="character" src="${configuration.IMAGES_BASE_URL}/Satoru_Gojo.png"/>`
};
